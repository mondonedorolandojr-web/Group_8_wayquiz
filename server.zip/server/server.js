import express from 'express';
import cors from 'cors';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { generateQuestionsFromText } from './questionGenerator.js';

// Load environment variables from server/.env
// Add the following to your .env file:
// GROQ_API_KEY=your_key_here
// Do not commit .env to source control; add .env to .gitignore.
dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Setup multer for file uploads
const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB max file size
});

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server is running!' });
});

// File upload and question generation endpoint
// This backend route proxies the Groq API request so the frontend never sends the API key directly to the browser.
app.post('/api/generate-questions', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // Read the uploaded file
    const filePath = req.file.path;
    let fileContent;
    try {
      fileContent = fs.readFileSync(filePath, 'utf-8');
    } catch (readError) {
      // If UTF-8 fails, try latin1 encoding
      try {
        fileContent = fs.readFileSync(filePath, 'latin1');
      } catch (latin1Error) {
        return res.status(400).json({ error: 'Unable to read the uploaded file. Please ensure it is a valid text file with UTF-8 or compatible encoding.' });
      }
    }

    if (!fileContent || fileContent.trim().length === 0) {
      return res.status(400).json({ error: 'The uploaded file is empty or contains no readable text.' });
    }

    // Generate questions from the text
    const questions = await generateQuestionsFromText(fileContent);

    // Clean up uploaded file
    fs.unlinkSync(filePath);

    res.json({ 
      success: true, 
      questions,
      questionCount: questions.length
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`✅ WayQuizz API Server running on http://localhost:${PORT}`);
  console.log(`📤 Upload endpoint: POST http://localhost:${PORT}/api/generate-questions`);
});
