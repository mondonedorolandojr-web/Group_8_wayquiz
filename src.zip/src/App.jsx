import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import LoginModal from './components/LoginModal';
import Home from './pages/Home';
import QuizApp from './QuizApp';
import About from './pages/About';
import Progress from './pages/Progress';
import HowItWorks from './pages/HowItWorks';

function App() {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [user, setUser] = useState(null);
  const [loginError, setLoginError] = useState('');

  useEffect(() => {
    const el = document.createElement("script")
    el.src = "https://www.tuqlas.com/chatbot.js"
    el.setAttribute("data-key", "tq_live_67c66f0f48d677685c657464226a09c490c76d63")
    el.setAttribute("data-api", "https://www.tuqlas.com")
    el.defer = true
    document.body.appendChild(el)
    return () => el.remove()
  }, [])

  return (
    <Router>
      <Navbar 
        user={user}
        onLogout={() => setUser(null)}
        onLoginClick={() => {
          setIsLoginMode(true);
          setIsLoginOpen(true);
          setLoginError('');
        }}
        onSignupClick={() => {
          setIsLoginMode(false);
          setIsLoginOpen(true);
          setLoginError('');
        }}
      />
      
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/quiz" element={<QuizApp user={user} onRequireLogin={() => {
          setIsLoginMode(true);
          setIsLoginOpen(true);
          setLoginError('');
        }} />} />
        <Route path="/about" element={<About />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/progress" element={<Progress />} />
      </Routes>
      
      <LoginModal 
        isOpen={isLoginOpen}
        onClose={() => {
          setIsLoginOpen(false);
          setLoginError('');
        }}
        isLogin={isLoginMode}
        onSwitch={() => {
          setIsLoginMode(!isLoginMode);
          setLoginError('');
        }}
        onLoginSuccess={(userData) => {
          setUser(userData);
          setIsLoginOpen(false);
          setLoginError('');
        }}
        loginError={loginError}
      />
    </Router>
  );
}

export default App;